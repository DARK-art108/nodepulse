# NodePulse

NodePulse is a lightweight Kubernetes monitoring and security stack that combines Prometheus, Grafana, and Trivy to deliver unified metrics and security insights.

## Components

- **Prometheus**: Metrics collection and alerting
- **Grafana**: Visualization and dashboards
- **Trivy**: Security scanning and vulnerability detection

## Prerequisites

- Kubernetes 1.19+
- Helm 3.8.0+
- kubectl
- Docker Desktop (for local development)

## Installation

1. Add the required Helm repositories:
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo add aquasecurity https://aquasecurity.github.io/helm-charts
helm repo update
```

2. Create the monitoring namespace:
```bash
kubectl create namespace monitoring
```

3. Install NodePulse:
```bash
helm install nodepulse . -n monitoring
```

## Accessing the Components

### Grafana
- URL: http://localhost:3000
- Default credentials:
  - Username: admin
  - Password: admin

### Prometheus
- URL: http://localhost:9090

### AlertManager
- URL: http://localhost:9093

## Configuration

The default configuration can be found in `values.yaml`. Key settings include:

- Prometheus:
  - Retention: 5 days
  - Storage: 10Gi
  - Resource limits: 1Gi memory, 500m CPU

- Grafana:
  - Storage: 5Gi
  - Resource limits: 256Mi memory, 100m CPU

- Trivy:
  - Daily vulnerability scans
  - Resource limits: 512Mi memory, 100m CPU

## Security Notes

- Change the default Grafana admin password in production
- Consider enabling additional security features in production environments

## License

MIT License 